package com.javalego.demo.test;

import java.util.List;

import javax.ejb.EJB;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.javalego.application.AppContext;
import com.javalego.data.DataContext;
import com.javalego.demo.ejb.MoviesServices;
import com.javalego.demo.entities.Empresa;

public class DemoTest
{
	public static final Logger logger = Logger.getLogger(DemoTest.class);

	@EJB
	private MoviesServices services;
	
	/**
	 * Ejemplo de carga del entorno en la clase de persistencia de Spring DemoPersistenceContext.
	 * 
	 * @throws Exception
	 */
	@Test
	public void environment() throws Exception
	{
		logger.info("Loaded environment " + AppContext.getCurrent().getEnvironmentName());

		// Obtener registros de entidades.
		List<Empresa> list = (List<Empresa>) DataContext.getProvider().findAll(Empresa.class);

		Empresa e = new Empresa();
		e.setNombre("EMPRESA EJB");
		e.setCif("CIFEJB");
		e.setRazon_social("RAZON SOCIAL EJB");

		Empresa e2 = new Empresa();
		e2.setNombre("EMPRESA EJB 2");
		e2.setCif("CIFEJB 2");
		e2.setRazon_social("RAZON SOCIAL EJB 2");

		//DataContext.getProvider().save(e);
		
		logger.info("Empresa: " + list.get(0).getNombre());
	}
}
