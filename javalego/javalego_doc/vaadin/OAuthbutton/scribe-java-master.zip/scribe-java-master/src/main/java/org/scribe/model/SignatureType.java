package org.scribe.model;

public enum SignatureType
{
  Header,
  QueryString
}
