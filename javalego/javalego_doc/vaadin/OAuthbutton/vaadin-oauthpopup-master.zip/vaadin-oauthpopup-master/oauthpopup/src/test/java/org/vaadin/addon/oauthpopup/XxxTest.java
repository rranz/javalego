package org.vaadin.addon.oauthpopup;

import junit.framework.Assert;
import org.junit.Test;

// JUnit tests here
public class XxxTest {

	@Test
	public void thisAlwaysPasses() {
		Assert.assertEquals(true, true);
	}
}
